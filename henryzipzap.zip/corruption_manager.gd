extends Node

const SAVE_PATH := "user://corruption_save.json"

const CORRUPTIBLE_ELEMENTS := ["respawn", "quit", "edit", "folder"]

var hit_count: int = 0
var broken_elements: Array[String] = []

func _ready() -> void:
	_load_corruption()

func register_hit() -> void:
	hit_count += 1

	if hit_count >= 10:
		return

	if hit_count >= 5:
		_try_corrupt_random_element()

func reset_hit_count() -> void:
	hit_count = 0

func should_game_over() -> bool:
	return hit_count >= 10

func _try_corrupt_random_element() -> void:
	var chance: float = (hit_count - 4) * 10.0
	if randf() * 100.0 > chance:
		return

	var available: Array[String] = []
	for element in CORRUPTIBLE_ELEMENTS:
		if not broken_elements.has(element):
			available.append(element)

	if available.is_empty():
		return

	var chosen: String = available[randi() % available.size()]
	broken_elements.append(chosen)
	print("Corrupted: ", chosen)
	_save_corruption()

func is_element_broken(element_name: String) -> bool:
	return broken_elements.has(element_name)

func fix_element(element_name: String) -> void:
	broken_elements.erase(element_name)
	_save_corruption()

func has_any_corruption() -> bool:
	return not broken_elements.is_empty()

func reset_all_corruption() -> void:
	broken_elements.clear()
	hit_count = 0
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(SAVE_PATH)

func _save_corruption() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		var data := {"broken_elements": broken_elements}
		file.store_string(JSON.stringify(data))
		file.close()

func _load_corruption() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if file:
			var json_string := file.get_as_text()
			file.close()
			var data = JSON.parse_string(json_string)
			if data and data.has("broken_elements"):
				broken_elements.assign(data["broken_elements"])
