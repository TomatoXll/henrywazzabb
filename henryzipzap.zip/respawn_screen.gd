extends CanvasLayer

const CHARACTER_SELECT_SCREEN_PATH := "res://character_select_screen.tscn"
const WARNING_SCREEN_PATH := "res://warning_screen.tscn"

func _ready() -> void:
	CursorManager.use_default_cursor()
	$Respawn.pressed.connect(_on_respawn_pressed)
	$Quit.pressed.connect(_on_quit_pressed)
	$EditButton.pressed.connect(_on_edit_pressed)
	$CodeFolderButton.pressed.connect(_on_code_folder_pressed)
	$CurrencyLabel.text = "Characters: %d" % CurrencyManager.character_count

func _show_warning_if_broken(element_name: String) -> bool:
	if CorruptionManager.is_element_broken(element_name):
		var warning_scene: PackedScene = load(WARNING_SCREEN_PATH)
		var warning := warning_scene.instantiate()
		warning.broken_element_name = element_name
		get_tree().root.add_child(warning)
		return true
	return false

func _on_respawn_pressed() -> void:
	if _show_warning_if_broken("respawn"):
		return

	CorruptionManager.reset_hit_count()
	get_tree().paused = false
	queue_free()
	get_tree().reload_current_scene()

func _on_quit_pressed() -> void:
	if _show_warning_if_broken("quit"):
		return

	get_tree().quit()

func _on_edit_pressed() -> void:
	if _show_warning_if_broken("edit"):
		return

	var character_select := character_select_screen_scene_load()
	get_tree().root.add_child(character_select)
	queue_free()

func character_select_screen_scene_load() -> Node:
	var scene: PackedScene = load(CHARACTER_SELECT_SCREEN_PATH)
	return scene.instantiate()

func _on_code_folder_pressed() -> void:
	if _show_warning_if_broken("folder"):
		return

	var folder_screen_scene: PackedScene = load("res://folder_select_screen.tscn")
	var folder_screen := folder_screen_scene.instantiate()
	get_tree().root.add_child(folder_screen)
	queue_free()
