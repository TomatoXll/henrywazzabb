extends CanvasLayer

const VIEW_SCREEN_PATH := "res://view_screen.tscn"
const FIX_SCREEN_PATH := "res://fix_screen.tscn"

var broken_element_name: String = ""

func _ready() -> void:
	CursorManager.use_default_cursor()

	$WindowPanel/MessageLabel.text = "Unexpected error. '%s' is not supported by the network.\nPress OK to continue. View to inspect. Fix to repair." % broken_element_name

	$WindowPanel/OkButton.pressed.connect(_on_ok_pressed)
	$WindowPanel/ViewButton.pressed.connect(_on_view_pressed)
	$WindowPanel/FixButton.pressed.connect(_on_fix_pressed)

func _on_ok_pressed() -> void:
	queue_free()

func _on_view_pressed() -> void:
	if ResourceLoader.exists(VIEW_SCREEN_PATH):
		var view_scene: PackedScene = load(VIEW_SCREEN_PATH)
		var view_screen := view_scene.instantiate()
		get_tree().root.add_child(view_screen)
	else:
		print("View screen not built yet")
	queue_free()

func _on_fix_pressed() -> void:
	if ResourceLoader.exists(FIX_SCREEN_PATH):
		var fix_scene: PackedScene = load(FIX_SCREEN_PATH)
		var fix_screen := fix_scene.instantiate()
		fix_screen.target_element = broken_element_name
		get_tree().root.add_child(fix_screen)
	else:
		print("Fix screen not built yet")
	queue_free()
