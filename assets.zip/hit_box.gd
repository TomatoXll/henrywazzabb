extends Area2D

@onready var damage_timer: Timer = $Timer

var player_body: Node2D = null

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		player_body = body
		deal_damage()
		damage_timer.start()

func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("player"):
		player_body = null
		damage_timer.stop()

func _on_timer_timeout() -> void:
	deal_damage()

func deal_damage() -> void:
	if player_body:
		player_body.take_damage(10)
