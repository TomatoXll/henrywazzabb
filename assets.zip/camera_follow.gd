extends Camera2D

@export var max_offset: float = 150.0
@export var follow_strength: float = 0.5

func _physics_process(delta: float) -> void:
	var mouse_pos: Vector2 = get_global_mouse_position()
	var player_pos: Vector2 = get_parent().global_position

	var direction: Vector2 = mouse_pos - player_pos
	var target_offset: Vector2 = direction * follow_strength
	target_offset = target_offset.limit_length(max_offset)

	offset = target_offset
