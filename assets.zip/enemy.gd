extends CharacterBody2D

signal died

@export var speed: float = 100.0
@export var max_health: int = 100
@export var knockback_friction: float = 800.0
@export var character_reward: int = 1

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D
@onready var hit_box: Area2D = $HitBox

var player: Node2D = null
var current_health: int
var is_dead: bool = false
var knockback_velocity: Vector2 = Vector2.ZERO

var active_statuses: Dictionary = {}

func _ready() -> void:
	player = get_tree().get_first_node_in_group("player")
	current_health = max_health

func _physics_process(delta: float) -> void:
	if is_dead:
		return

	_process_statuses(delta)

	if knockback_velocity.length() > 10.0:
		velocity = knockback_velocity
		knockback_velocity = knockback_velocity.move_toward(Vector2.ZERO, knockback_friction * delta)
		move_and_slide()
		return

	if player == null:
		return

	nav_agent.target_position = player.global_position

	if nav_agent.is_navigation_finished():
		return

	var next_path_position: Vector2 = nav_agent.get_next_path_position()
	var direction := (next_path_position - global_position).normalized()

	velocity = direction * speed
	move_and_slide()

	update_animation(direction)

func take_damage(amount: int) -> void:
	if is_dead:
		return

	current_health -= amount
	print("Enemy health: ", current_health)

	if current_health <= 0:
		die()

func apply_knockback(direction: Vector2, force: float) -> void:
	knockback_velocity = direction * force

func apply_status(status_name: String, damage_per_tick: int, tick_interval: float, duration: float) -> void:
	active_statuses[status_name] = {
		"damage_per_tick": damage_per_tick,
		"tick_interval": tick_interval,
		"time_since_last_tick": 0.0,
		"remaining_duration": duration,
	}

func _process_statuses(delta: float) -> void:
	var statuses_to_remove: Array = []

	for status_name in active_statuses.keys():
		var status: Dictionary = active_statuses[status_name]
		status["remaining_duration"] -= delta
		status["time_since_last_tick"] += delta

		if status["time_since_last_tick"] >= status["tick_interval"]:
			status["time_since_last_tick"] = 0.0
			take_damage(status["damage_per_tick"])

		if status["remaining_duration"] <= 0.0:
			statuses_to_remove.append(status_name)

	for status_name in statuses_to_remove:
		active_statuses.erase(status_name)

func die() -> void:
	is_dead = true
	velocity = Vector2.ZERO
	knockback_velocity = Vector2.ZERO

	hit_box.set_deferred("monitoring", false)
	$CollisionShape2D.set_deferred("disabled", true)

	CurrencyManager.add_characters(character_reward)

	print("Enemy died")
	died.emit()
	queue_free()

func update_animation(direction: Vector2) -> void:
	if abs(direction.x) > abs(direction.y):
		animated_sprite.flip_h = direction.x < 0
		animated_sprite.play("walk_side")
	else:
		if direction.y > 0:
			animated_sprite.play("walk_down")
		else:
			animated_sprite.play("walk_up")
