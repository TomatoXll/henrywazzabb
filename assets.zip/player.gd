extends CharacterBody2D

@export var speed: float = 200.0
@export var max_health: int = 100
@export var slash_attack_scene: PackedScene
@export var attack_cooldown: float = 0.5
@export var respawn_screen_scene: PackedScene

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

const CUSTOM_ANIMATION_FRAME_COUNTS := {
	"walk_down": 4,
	"walk_up": 4,
	"walk_side": 8,
	"idle_down": 1,
	"idle_up": 1,
	"attack": 6,
}

var last_direction: String = "down"
var last_flip: bool = false
var current_health: int
var is_dead: bool = false
var can_attack: bool = true
var is_attacking: bool = false
var base_speed: float = 0.0
var base_attack_cooldown: float = 0.0

func _ready() -> void:
	current_health = max_health
	_apply_custom_sprites()
	base_speed = speed
	base_attack_cooldown = attack_cooldown
	speed = base_speed * (1.0 + HenryStatManager.speed_bonus_percent / 100.0)
	print("Base speed: ", base_speed, " → Actual speed: ", speed, " (bonus: ", HenryStatManager.speed_bonus_percent, "%)")

func _apply_custom_sprites() -> void:
	animated_sprite.sprite_frames = animated_sprite.sprite_frames.duplicate(true)
	var sprite_frames: SpriteFrames = animated_sprite.sprite_frames

	for animation_name in CUSTOM_ANIMATION_FRAME_COUNTS.keys():
		var frame_count: int = CUSTOM_ANIMATION_FRAME_COUNTS[animation_name]

		for i in range(frame_count):
			var custom_path := "user://henry_custom/%s_%d.png" % [animation_name, i]

			if FileAccess.file_exists(custom_path):
				var img := Image.load_from_file(custom_path)
				var custom_texture := ImageTexture.create_from_image(img)
				sprite_frames.set_frame(animation_name, i, custom_texture)

func _physics_process(delta: float) -> void:
	if is_dead:
		return

	var input_direction := Vector2.ZERO
	input_direction.x = Input.get_axis("move_left", "move_right")
	input_direction.y = Input.get_axis("move_up", "move_down")
	input_direction = input_direction.normalized()

	velocity = input_direction * speed
	move_and_slide()

	if not is_attacking:
		update_animation(input_direction)

func _unhandled_input(event: InputEvent) -> void:
	if is_dead:
		return

	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			if can_attack:
				perform_attack()

func perform_attack() -> void:
	can_attack = false
	is_attacking = true

	var mouse_pos: Vector2 = get_global_mouse_position()
	var direction: Vector2 = (mouse_pos - global_position).normalized()

	animated_sprite.flip_h = direction.x < 0
	animated_sprite.play("attack")

	var slash := slash_attack_scene.instantiate()
	get_parent().add_child(slash)
	slash.global_position = global_position
	slash.rotation = direction.angle()

	await animated_sprite.animation_finished
	is_attacking = false

	var effective_cooldown: float = base_attack_cooldown * (1.0 - HenryStatManager.attack_speed_bonus_percent / 100.0)
	await get_tree().create_timer(effective_cooldown).timeout
	can_attack = true

func take_damage(amount: int) -> void:
	if is_dead:
		return

	if randf() * 100.0 < HenryStatManager.dexterity_bonus_percent:
		print("Dodged!")
		return

	current_health -= amount
	print("Player health: ", current_health)

	if current_health <= 0:
		die()

func die() -> void:
	is_dead = true
	velocity = Vector2.ZERO
	print("you die")

	var respawn_screen := respawn_screen_scene.instantiate()
	get_tree().root.add_child(respawn_screen)

	get_tree().paused = true

func update_animation(direction: Vector2) -> void:
	if direction == Vector2.ZERO:
		animated_sprite.flip_h = last_flip
		animated_sprite.play("idle_" + last_direction)
		return

	if abs(direction.x) > abs(direction.y):
		last_direction = "side"
		last_flip = direction.x < 0
		animated_sprite.flip_h = last_flip
		animated_sprite.play("walk_side")
	else:
		last_direction = "down" if direction.y > 0 else "up"
		last_flip = false
		animated_sprite.flip_h = false
		animated_sprite.play("walk_" + last_direction)
