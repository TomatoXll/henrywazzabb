extends CanvasLayer

const CHARACTER_SELECT_SCREEN_PATH := "res://character_select_screen.tscn"
const FOLDER_SELECT_SCREEN_PATH := "res://folder_select_screen.tscn"

func _ready() -> void:
	CursorManager.use_default_cursor()
	$Respawn.pressed.connect(_on_respawn_pressed)
	$Quit.pressed.connect(_on_quit_pressed)
	$EditButton.pressed.connect(_on_edit_pressed)
	$CodeFolderButton.pressed.connect(_on_code_folder_pressed)
	$CurrencyLabel.text = "Characters: %d" % CurrencyManager.character_count

func _on_code_folder_pressed() -> void:
	var folder_screen_scene: PackedScene = load(FOLDER_SELECT_SCREEN_PATH)
	var folder_screen := folder_screen_scene.instantiate()
	get_tree().root.add_child(folder_screen)
	queue_free()
	
func _on_respawn_pressed() -> void:
	get_tree().paused = false
	queue_free()
	get_tree().reload_current_scene()

func _on_quit_pressed() -> void:
	get_tree().quit()

func _on_edit_pressed() -> void:
	var character_select_scene: PackedScene = load(CHARACTER_SELECT_SCREEN_PATH)
	var character_select := character_select_scene.instantiate()
	get_tree().root.add_child(character_select)
	queue_free()
