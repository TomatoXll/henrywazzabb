extends Area2D

@export var damage: int = 10
@export var knockback_force: float = 400.0

const STATUS_CONFIG := {
	"burn": {"tick_interval": 1.0, "duration": 5.0, "damage_percent": 0.2},
	"freeze": {"tick_interval": 1.0, "duration": 3.0, "damage_percent": 0.2},
}

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	_apply_custom_sprites()
	animated_sprite.play("slash")

	body_entered.connect(_on_body_entered)

	await animated_sprite.animation_finished
	queue_free()

func _apply_custom_sprites() -> void:
	var sprite_frames: SpriteFrames = animated_sprite.sprite_frames
	var frame_count: int = sprite_frames.get_frame_count("slash")

	for i in range(frame_count):
		var custom_path := "user://darp_custom/slash_%d.png" % i
		if FileAccess.file_exists(custom_path):
			var img := Image.load_from_file(custom_path)
			var custom_texture := ImageTexture.create_from_image(img)
			sprite_frames.set_frame("slash", i, custom_texture)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("enemy"):
		var total_damage: int = damage + WeaponEffectManager.damage_bonus
		body.take_damage(total_damage)

		var knock_direction: Vector2 = (body.global_position - global_position).normalized()
		body.apply_knockback(knock_direction, knockback_force)

		for effect_name in WeaponEffectManager.active_effects:
			if STATUS_CONFIG.has(effect_name):
				var config: Dictionary = STATUS_CONFIG[effect_name]
				var tick_damage: int = int(total_damage * config["damage_percent"])
				body.apply_status(effect_name, tick_damage, config["tick_interval"], config["duration"])
