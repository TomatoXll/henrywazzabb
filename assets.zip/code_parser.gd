extends RefCounted

const EFFECT_REGISTRY := {
	"fire": "burn",
	"ice": "freeze",
}

static func parse(code: String) -> Dictionary:
	var lines: PackedStringArray = code.split("\n")
	var errors: Array = []
	var effects: Array[String] = []
	var line_index := 0
	var block_found := false

	while line_index < lines.size():
		var line: String = lines[line_index].strip_edges()

		if line == "":
			line_index += 1
			continue

		block_found = true
		var block_result := _parse_block(lines, line_index)

		if block_result["error"] != "":
			errors.append({"line": block_result["error_line"], "message": block_result["error"]})
		else:
			effects.append(block_result["status_effect"])

		line_index = block_result["next_index"]

	var is_fully_valid: bool = block_found and errors.is_empty()

	return {
	"is_fully_valid": is_fully_valid,
	"effects": effects if is_fully_valid else [],
	"errors": errors,
	"character_count": count_significant_characters(code),
}

static func _parse_block(lines: PackedStringArray, start_index: int) -> Dictionary:
	var result := {
		"error": "",
		"error_line": start_index + 1,
		"status_effect": "",
		"next_index": start_index + 1,
	}

	if start_index >= lines.size():
		result["error"] = "Unexpected end of code, expected 'import weapon_effect'"
		return result

	var import_line: String = lines[start_index].strip_edges()
	if import_line != "import weapon_effect":
		result["error"] = "Line must be exactly: import weapon_effect"
		result["error_line"] = start_index + 1
		result["next_index"] = start_index + 1
		return result

	if start_index + 1 >= lines.size():
		result["error"] = "Missing effect assignment line after import"
		result["error_line"] = start_index + 2
		result["next_index"] = start_index + 1
		return result

	var assign_line: String = lines[start_index + 1].strip_edges()
	var assign_regex := RegEx.new()
	assign_regex.compile("^weapon_effect\\s*=\\s*\"([a-zA-Z_]+)\"$")
	var assign_match := assign_regex.search(assign_line)

	if not assign_match:
		result["error"] = "Line must match: weapon_effect = \"effect_name\""
		result["error_line"] = start_index + 2
		result["next_index"] = start_index + 2
		return result

	var effect_name_raw: String = assign_match.get_string(1)
	var effect_name: String = effect_name_raw.to_lower()

	if not EFFECT_REGISTRY.has(effect_name):
		result["error"] = "Unknown effect '%s'. Known effects: %s" % [effect_name_raw, str(EFFECT_REGISTRY.keys())]
		result["error_line"] = start_index + 2
		result["next_index"] = start_index + 2
		return result

	if start_index + 2 >= lines.size():
		result["error"] = "Missing if condition line"
		result["error_line"] = start_index + 3
		result["next_index"] = start_index + 2
		return result

	var if_line: String = lines[start_index + 2].strip_edges()
	if if_line != "if sword.hit(enemy):":
		result["error"] = "Line must be exactly: if sword.hit(enemy):"
		result["error_line"] = start_index + 3
		result["next_index"] = start_index + 3
		return result

	if start_index + 3 >= lines.size():
		result["error"] = "Missing indented effect line after if statement"
		result["error_line"] = start_index + 4
		result["next_index"] = start_index + 3
		return result

	var effect_line: String = lines[start_index + 3]
	var expected_suffix: String = EFFECT_REGISTRY[effect_name]
	var effect_regex := RegEx.new()
	effect_regex.compile("^\\s+enemy\\.(\\w+)_effect\\s*=\\s*True$")
	var effect_match := effect_regex.search(effect_line)

	if not effect_match:
		result["error"] = "Indented line must match: enemy.<effect>_effect = True (with indentation)"
		result["error_line"] = start_index + 4
		result["next_index"] = start_index + 4
		return result

	var written_suffix: String = effect_match.get_string(1)
	if written_suffix != expected_suffix:
		result["error"] = "Effect '%s' should set 'enemy.%s_effect', not 'enemy.%s_effect'" % [effect_name, expected_suffix, written_suffix]
		result["error_line"] = start_index + 4
		result["next_index"] = start_index + 4
		return result

	result["status_effect"] = expected_suffix
	result["next_index"] = start_index + 4
	return result
	
static func count_significant_characters(text: String) -> int:
	var count := 0
	for character in text:
		if character != " " and character != "\n" and character != "\t" and character != "\r":
			count += 1
	return count
